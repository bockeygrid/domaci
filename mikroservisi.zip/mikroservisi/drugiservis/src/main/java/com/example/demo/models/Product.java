package com.example.demo.models;


import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.TypeAlias;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "products")
@TypeAlias("Product")
public class Product
{
    @Id
    private String id;

    public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}



	private String name;
    private float price;

    



   
    public Product()
    {
    }


    public Product(String name,  float price)
    {
        this.setName(name);
    
        this.setPrice(price);
        
        
    }



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public float getPrice() {
		return price;
	}



	public void setPrice(float price) {
		this.price = price;
	}
    }

