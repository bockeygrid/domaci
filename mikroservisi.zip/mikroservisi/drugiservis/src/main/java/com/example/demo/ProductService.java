package com.example.demo;

import java.util.List;

import com.example.demo.models.Product;

public interface ProductService {
	
	 public abstract List<Product> findAll();

}
