package com.example.demo;

import java.util.List;
import com.example.demo.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.models.Product;



@RestController


public class ProductController {
	
	
@Autowired
ProductService productService;

@GetMapping(path = "/product")
    public  List<Product> all() {
	return productService.findAll();

}



@GetMapping("/product/getprod")
public String findName(@RequestParam(name="prodId") String Id) {
	
	for(int i = 0; i < productService.findAll().size(); i++) {
		if(productService.findAll().get(i).getId().equals(Id)) return productService.findAll().get(i).getName();
	}
  return null;
}	
}