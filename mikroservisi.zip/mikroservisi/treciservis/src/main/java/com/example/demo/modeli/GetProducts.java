package com.example.demo.modeli;

public class GetProducts {
 
	  public static final String URL = "http://localhost:8081/products";
	  
	    static final String URL_XML= "http://localhost:8081/products.xml";
	    static final String URL_JSON= "http://localhost:8081/products.json";
	 
	    
	 
	       
		
	}
    


