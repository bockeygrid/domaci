package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.client.RestTemplate;

import com.example.demo.modeli.GetProducts;


@SpringBootApplication(scanBasePackages={"com.example.demo.modeli.OrderService"})

public class TreciservisApplication {

	public static void main(String[] args) {
		SpringApplication.run(TreciservisApplication.class, args);
		
		
		
		RestTemplate restTemplate = new RestTemplate();
		
		String imeAdresa = restTemplate.getForObject("http://localhost:8080/userses",String.class);{
			
			 System.out.println(imeAdresa);
			
		}
		
//		 RestTemplate restTemplate = new RestTemplate();;
//		 
//	       
//		
//	        String result = restTemplate.getForObject(GetProducts.URL, String.class);
//	 
//	        System.out.println(result);
//	    }
		
	}
}


