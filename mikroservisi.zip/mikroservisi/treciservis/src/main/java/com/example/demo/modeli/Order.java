package com.example.demo.modeli;

import org.springframework.web.client.RestTemplate;

public class Order {
	
	private String prodname;
	private String prodaddress;
	private String product;
	private float prodprice;
	
	
//	RestTemplate restTemplate = new RestTemplate();
//	
//	String imeAdresa = restTemplate.getForObject("http://localhost:8080/userses",String.class);{
//		
//		
//	}

}
