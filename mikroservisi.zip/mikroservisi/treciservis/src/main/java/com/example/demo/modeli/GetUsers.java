package com.example.demo.modeli;

import org.springframework.web.client.RestTemplate;

public class GetUsers {
	
	public static final String URL = "http://localhost:8080/userses";
	  
    static final String URL_XML= "http://localhost:8080/userses.xml";
    static final String URL_JSON= "http://localhost:8080/userses.json";
 
	
	
}
