package com.example.demo.modeli;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class OrderController {
	
	@Autowired
	OrderService orderService;
	
	@GetMapping("/order")
	
	public String checkout(@RequestParam(name="name") String productId,@RequestParam(name="address")String persnalID) {
		return persnalID;
	}
		
		
		public  List<Order> all() {
     	return orderService.findAll();
		
	}
}
			
	
			
			
			
		