package com.example.demo.modeli;

import java.util.List;




public interface OrderService {
     public abstract List<Order> findAll();
	
	

}

