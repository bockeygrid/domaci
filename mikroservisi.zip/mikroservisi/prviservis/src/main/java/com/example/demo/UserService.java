package com.example.demo;

import java.util.List;


public interface UserService {
    public abstract List<Users> findAll();
	
	

}
