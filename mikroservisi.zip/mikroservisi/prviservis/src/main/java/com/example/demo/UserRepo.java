package com.example.demo;


import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;


	
	
	
	@Repository 
	
	public interface UserRepo extends MongoRepository<Users, String>{
		
		
	//List<Users> findAddress (final String address);
		
		
	}


