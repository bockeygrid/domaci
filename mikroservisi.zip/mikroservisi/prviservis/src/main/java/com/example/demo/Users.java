package com.example.demo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

//@Document

public class Users {
	
	@Id private String ID;
	private String name;
	private String address;
	
	
	public String getId() {
		return ID;
	}
	
	public void setId(String id) {
		ID = id;
	}

	
	public String getName() {
		
		return name;
		
	}
	
	public void setName(String name) {
		this.name = name;
		
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	
	public Users(String name, String address,String ID) {
		
		this.name = name;
		this.address = address;
		this.ID = ID;
	}
   
}
